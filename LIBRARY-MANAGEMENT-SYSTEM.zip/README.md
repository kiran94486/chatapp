# Library Management System

It is an Automated Library management system with PyQt5 interface

## Requirement

```python
pip install requirements.txt
```
## Execute

```python
py index.py
or
python index.py
```

## Login

* Username:Nitish Kumar

* password:1234


## Signup

---
Create your own account
---
