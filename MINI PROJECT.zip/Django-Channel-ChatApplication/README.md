# Django-Channel-Chat Application

A Chat application made in Django using channels for async handling of web socket.  
Its a learning-by-doing project. Work in progress.
