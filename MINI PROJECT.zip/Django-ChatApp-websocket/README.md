# Django_ChatApp_websocket
Created a django chat app using websockets,django-channels.
You can read more about it from here https://channels.readthedocs.io/en/stable/

# Steps to follow
 - git clone https://github.com/itssunny322/Django_ChatApp_websocket.git
 - cd Django_chatApp_websocket
 - pip3 install -r requirements.txt
 - python manage.py runserver
 - Signup 
 - Login
 - Select the user from list 
 - Start texting

# Languages and frameworks
 - Python
 - Django, DRF
 - HTML, CSS, JS

# Tool
 - pycharm or vscode


